﻿$Certificate = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object {$_.Subject -match "o365ready"}
$ADFSFarmHt = @{
    CertificateThumbprint = $Certificate.Thumbprint 
    GroupServiceAccountIdentifier = "CORP\svcADFS`$"
    PrimaryComputerName = "acme-adfs01"
}
Add-AdfsFarmNode @ADFSFarmHt
