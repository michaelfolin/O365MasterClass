﻿$Certificate = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object {$_.Subject -match "o365ready"}
$ADFSFarmHt = @{
     CertificateThumbprint = $Certificate.Thumbprint 
     FederationServiceDisplayName = "ACME" 
     FederationServiceName = ($Certificate.DnsNameList | Where-Object {$_ -match "sts"}).UniCode
     GroupServiceAccountIdentifier = "CORP\svcADFS`$"
}

Install-AdfsFarm @ADFSFarmHt
