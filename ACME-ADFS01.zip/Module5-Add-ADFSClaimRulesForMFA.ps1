﻿$ClaimsFile = "c:\temp\transformrules.txt"
$ByPassMFAClaims = @"

@RuleTemplate = "PassThroughClaims"
@RuleName = "Passtrough - InsideCorporateNetwork"
c:[Type == "http://schemas.microsoft.com/ws/2012/01/insidecorporatenetwork"]
 => issue(claim = c);

@RuleName = "Passtrough - PSSO"
c:[Type == "http://schemas.microsoft.com/2014/03/psso"]
 => issue(claim = c);
"@
#Export Existing rules to claimsfile
Get-AdfsRelyingPartyTrust -Name "Microsoft Office 365 Identity Platform" | Select-Object -ExpandProperty IssuanceTransformRules | Out-File -FilePath $ClaimsFile -Force
#Append the new claim rules
$ByPassMFAClaims | Out-File -FilePath $ClaimsFile -Append -Force 
#Apply the settings to the ADFS server / relying party
Set-AdfsRelyingPartyTrust -TargetName  "Microsoft Office 365 Identity Platform" -IssuanceTransformRulesFile $ClaimsFile -Verbose