﻿Set-AdfsGlobalWebContent –CompanyName "ACME"

Set-AdfsWebTheme -TargetName default -Logo @{path="C:\labfiles\logo.png"}
Set-AdfsWebTheme -TargetName default -Illustration @{path="C:\labfiles\illustration.png"}
Set-AdfsGlobalWebContent -SignInPageDescriptionText "Welcome to A Company that Makes Everything."
Set-AdfsGlobalWebContent -HelpDeskLink https://helpdesk.acme.com -HelpDeskLinkText Help

