Configuration InstallExchange
{
    param
    (
        [PSCredential]$AdminCreds,
        $ExOrgName
    )

    Import-DscResource -Module xExchange
    Import-DscResource -Module xPendingReboot
    Import-DscResource -Module PSDesiredStateConfiguration

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true   
        }

        #Check if a reboot is needed before installing Exchange
        xPendingReboot BeforePreReqInstall
        {
            Name      = "BeforePreReqInstall"

        }
        Package InstallFilterPack64 {
            Ensure = "Present"
            Name = "InstallFilterPack64"
            Path = "C:\Temp\ExchangePreReq\FilterPack64bit.exe"
            Arguments = "/quiet /norestart"
            ProductID = "95140000-2000-0409-1000-0000000FF1CE"
            DependsOn  = '[xPendingReboot]BeforePreReqInstall'
        }

        Package InstallUCMA {
            Ensure = "Present"
            Name = "InstallUCMA"
            Path = "C:\Temp\ExchangePreReq\UcmaRuntimeSetup.exe"
            Arguments = "/quiet /norestart"
            ProductID = "41D635FE-4F9D-47F7-8230-9B29D6D42D31"
            DependsOn  = '[Package]InstallFilterPack64'
        }

        xPendingReboot BeforeExchangeInstall
        {
            Name      = "BeforeExchangeInstall"
            DependsOn = '[Package]InstallUCMA'
        }

        xExchInstall InstallExchangePrepareSchema
        {
            Path       = "C:\Temp\Exchange\Setup.exe"
            Arguments  = "/IAcceptExchangeServerLicenseTerms /PrepareSchema"
            Credential = $AdminCreds

            DependsOn  = '[xPendingReboot]BeforeExchangeInstall'
        }
        
        #Do the Exchange install
        xExchInstall InstallExchangePrepareAD
        {
            Path       = "C:\Temp\Exchange\Setup.exe"
            Arguments  = "/IAcceptExchangeServerLicenseTerms /PrepareAD /OrganizationName:$ExOrgName"
            Credential = $AdminCreds

            DependsOn  = '[xExchInstall]InstallExchangePrepareSchema'
        }

        xExchInstall InstallExchangePrepareDomain
        {
            Path       = "C:\Temp\Exchange\Setup.exe"
            Arguments  = "/PrepareDomain /IAcceptExchangeServerLicenseTerms"
            Credential = $AdminCreds

            DependsOn  = '[xExchInstall]InstallExchangePrepareAD'
        }
        
        xExchInstall InstallExchange
        {
            Path       = "C:\Temp\Exchange\Setup.exe"
            Arguments  = "/m:Install /Roles:ca,mb,mt /IAcceptExchangeServerLicenseTerms /InstallWindowsComponents"
            Credential = $AdminCreds

            DependsOn  = '[xExchInstall]InstallExchangePrepareDomain'
        }

        #See if a reboot is required after installing Exchange
        xPendingReboot AfterExchangeInstall
        {
            Name      = "AfterExchangeInstall"

            DependsOn = '[xExchInstall]InstallExchange'
        }
    }
}


