﻿New-RemoteMailbox -Name "Michael Scott (micsco)" `
                  -DisplayName "Michael Scott (micsco)" `
                  -Password (ConvertTo-SecureString -AsPlainText -String 'Pa$$w0rd' -Force) `
                  -UserPrincipalName "michael.scott@lab22339.o365ready.com" `
                  -SamAccountName "micsco" `
                  -FirstName "Michael" `
                  -LastName "Scott" `
                  -ResetPasswordOnNextLogon $false `
                  -OnPremisesOrganizationalUnit "OU=Users,OU=ACME,DC=corp,DC=acme,DC=com" `
                  
                  