﻿#Connect to Exchange Online
$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $Session


Get-MigrationBatch 

Get-MigrationUser

Get-MigrationUserStatistics -Identity benjamin.beverly@lab19748.o365ready.com | fl

Get-MoveRequest | Get-MoveRequestStatistics 

