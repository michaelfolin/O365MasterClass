﻿[CmdletBinding(SupportsShouldProcess=$true)]
param (
    [switch]$ForceLogin,
    [switch]$DoItOverAgain,
    [switch]$Log,
    [string]$Creds = "",
    [ValidateSet("Start", "Stop","UpdateVMSize")]
    [string]$PreFlightCheck 
)
#Define variables and Uri's to scripts/assets
$RGName = "O365MasterClass"
$Location = "North Europe"
$TemplateUri = "https://raw.githubusercontent.com/jimmylindo/O365MasterClass/master/azuredeploy-masterclass-v1.json"
$FinalizeScript = "https://raw.githubusercontent.com/jimmylindo/O365MasterClass/master/Finalize-MasterClassVM.ps1"
$DSCAssetLocation = "https://raw.githubusercontent.com/jimmylindo/O365MasterClass/master/"
function Start-JDSleep {
    param (
        $message,
        $sleeptime
    )
    foreach($i in (1..$SleepTime)) {
        $percentage = $i / $SleepTime
        $remaining = New-TimeSpan -Seconds ($SleepTime - $i)
        $message = "{0:p0} complete, remaining time {1}" -f $percentage, $remaining
        Write-Progress -CurrentOperation $message -PercentComplete ($percentage * 100) -Activity "$message"
        Start-Sleep 1
    }   
}
Function global:New-RDP {
    param(
        [string]$Path = $(throw "A path to the new RDP file is required."),
        [string]$Server = "",
        [switch]$PassThru,
        [switch]$Force
    )

    if (!(Test-Path $path) -or $force) {
        Set-Content -Path $path -Value "full address:s:$server" -Force
        if ($passthru) {
            Get-ChildItem -Path $path
        }
    } else {
        throw "Path already exists, use the -Force switch."
    }
}

#Verify Azure PowerShell version 
$AzureModule = Get-Module -ListAvailable AzureRM.Compute 
if ($Azuremodule.Version.Major -lt 1) {
    break "Your Azuremodule does not support Resource manager properly, please install the latest version"
}
#Verify azure connection, or prompt for login
if ($Creds) {
        $AdminUsername = $Creds
        $AdminPassword = (ConvertTo-SecureString -AsPlainText 'Hejhopp82@' -Force)
        $AzureCreds = (New-Object System.Management.Automation.PSCredential -ArgumentList $AdminUsername, $AdminPassword)
        Login-AzureRmAccount -Credential $AzureCreds
}
$AzureSubScription = Get-AzureRmSubscription
if (-not($AzureSubScription) -or $ForceLogin) {
    Login-AzureRmAccount  
}
#Reset the entire environment if $DoItOverAgain switch has been used
if ($DoItOverAgain) {
    Write-Verbose "DoItOverAgain Switch was used, will remove all existing resources"
    Remove-AzureRmResourceGroup -Name $RGName -Force 
    Write-Verbose "Waiting additional 30 seconds after resource group removal..."
    Start-Sleep 30
}
if ($Log) {
    $logfile = "{0}\{1}.log" -f $PSScriptRoot,$creds
    Start-Transcript -Path $logfile -Append -Force
    
}
if ($PreFlightCheck) {
    switch ($PreFlightCheck) {
        'Start' {
            write-verbose "Starting all VM's"
            $IPAddress = Get-AzureRmPublicIpAddress -Name publicIp -ResourceGroupName O365MasterClass | Select-Object -ExpandProperty IPAddress
            New-RDP -Server $IPAddress -Path "$PSScriptRoot\$($creds)-$($IPAddress)-DC01.rdp" -Force 
            New-RDP -Server "$($IPAddress):3390" -Path "$PSScriptRoot\$($creds)-$($IPAddress)-EX01.rdp" -Force 
            Start-AzureRmVM -Name "ACME-DC01" -ResourceGroupName $RGName 
            Start-AzureRmVM -Name "ACME-EX01" -ResourceGroupName $RGName 
            Start-AzureRmVM -Name "ACME-CL01" -ResourceGroupName $RGName 
            Get-AzureRmVM | Where-Object {$_.Name -ne "ACME-DC01" -or $_.name -ne "ACME-EX01" -or $_.Name -ne "ACME-CL01"} | Start-AzureRmVM
        }
        'Stop' {
            write-verbose "Stopping all VM's"
            Stop-AzureRmVM -Name "ACME-EX01" -ResourceGroupName $RGName -Force
            Stop-AzureRmVM -Name "ACME-DC01" -ResourceGroupName $RGName -Force
            
            Stop-AzureRmVM -Name "ACME-CL01" -ResourceGroupName $RGName -Force
            Get-AzureRmVM | Where-Object {$_.Name -ne "ACME-DC01" -or $_.name -ne "ACME-EX01" -or $_.Name -ne "ACME-CL01"} | Stop-AzureRmVM -Force
        }
        'UpdateVMSize' {
            #Remove-AzureRmVMCustomScriptExtension -ResourceGroupName $RGName -VMName ACME-EX01 -Name "CustomScript" -Force
            'Standard_D1' | ForEach-Object -Process {
                $Size = $_
                'ACME-CL01','ACME-CL02','ACME-DC01' | ForEach-Object -Process {
                    $VM = Get-AzureRmVM -ResourceGroupName $RGName -Name $_
                    $VM.HardwareProfile.VirtualMachineSize = $Size
                    $VM | Update-AzureRmVM
                }
                
            }
            'Standard_D3_v2' | ForEach-Object -Process {
                
                $VM = Get-AzureRmVM -ResourceGroupName $RGName -Name ACME-EX01
                $VM.HardwareProfile.VirtualMachineSize = $_ 
                $VM | Update-AzureRmVM 
            }
        }
    }
    
} else {

    #Check for resource group
    $RGroup = Get-AzureRmResourceGroup -Name $RGName -Location $Location -ErrorAction Ignore -WarningAction Ignore

    #try {
    #Create resource group if not exists
    if (-not($RGroup)) {
        New-AzureRmResourceGroup -Name $RGName -Location $Location -Force -ErrorAction Stop
        
    }

    #Check if storage account exists , generate new if not.
    $StorageAccount = Get-AzureRmStorageAccount | Where-Object {$_.StorageAccountName -like "O365*"} -ErrorAction Ignore

    if ($StorageAccount) {
        $DNSName = $StorageAccount.StorageAccountName
    } else {
        $DNSName = "{0}{1}" -f $rgname.ToLower(),[guid]::NewGuid().guid.split("-")[0]
        New-AzureRmStorageAccount -ResourceGroupName $RGName -Name $DNSName -Type Standard_LRS -Location $Location -Verbose
        #$blobName = "Microsoft.Compute/Images/vhds/template-osDisk.e00e29d5-eb33-4227-99a0-556c8e691bf3.vhd" 
        # Source Storage Account Information #
        #$sourceStorageAccountName = "365lab"
        #$sourceKey = "IEg+b7wPfW9I4nvPQa6g14kSOwBcnnyLxKiy8muDKHtUER+V0XlQcMDO4b7D/jy77yGxGj6UKANXh42vvKPOUA=="
        #$sourceContext = New-AzureStorageContext –StorageAccountName $sourceStorageAccountName -StorageAccountKey $sourceKey  
        #$sourceContainer = "system"

        #Edited by Stefan Ivemo pekar mot storage blob i Stefans MSDN subscription
         $blobName = "Microsoft.Compute/Images/mytemplates/template-osDisk.3c1b9f06-b5d1-483f-afb7-5c99390c4812.vhd" 
        # Source Storage Account Information #
        $sourceStorageAccountName = "rgw10template8757"
        $sourceKey = "4w3p4Xa9A9HFhkdbf4/J/0Q3fpA4Th0w415MhKARDOdEuVf9JrTwkVj1eMEfZ4GBLReKY+0RyKdZGUAR89VkgA=="
        $sourceContext = New-AzureStorageContext –StorageAccountName $sourceStorageAccountName -StorageAccountKey $sourceKey  
        $sourceContainer = "system"

        # Destination Storage Account Information #
        $destinationStorageAccountName = (Get-AzureRmStorageAccount | Where-Object {$_.StorageAccountName -like "o365*"}).StorageAccountName
        $destinationKey = (Get-AzureRmStorageAccountKey -Name $destinationStorageAccountName -ResourceGroupName $RGName).Key1
        $destinationContext = New-AzureStorageContext –StorageAccountName $destinationStorageAccountName -StorageAccountKey $destinationKey  

        # Create the destination container #
        $destinationContainerName = "destinationvhds"
        New-AzureStorageContainer -Name $destinationContainerName -Context $destinationContext 

        # Copy the blob # 
        $blobCopy = Start-AzureStorageBlobCopy -DestContainer $destinationContainerName `
                            -DestContext $destinationContext `
                            -SrcBlob $blobName `
                            -Context $sourceContext `
                            -SrcContainer $sourceContainer
        while (($blobCopy | Get-AzureStorageBlobCopyState).Status -eq "Pending") {
            Start-Sleep -Seconds 30
            $blobCopy | Get-AzureStorageBlobCopyState
        }

    }  

    #Create deployment from json Template
    $parameters = @{
                "PublicDNSName"="$DNSName"
                "NewStorageAccount"="$DNSName"
                "DOmainName"="corp.acme.com"
                "adminUserName"='sysadmin'
                "adminPassword"='Pa$$w0rd'
                "assetLocation"=$DSCAssetLocation
    }
    Write-Verbose "Will start deployment $DNSName in $RGName ($Location)"
     $GroupDeploymentHt = @{
        Name = "Office365MasterClass"
        ResourceGroupName = "$RGName"
        TemplateParameterObject = $parameters 
        TemplateUri = $TemplateUri
    }
    try {
        New-AzureRmResourceGroupDeployment @GroupDeploymentHt -Verbose -ErrorAction Stop
        Write-Output "Successfully deployed the environment"
    } catch {
        Write-Warning $_ 
        break
    }
    Remove-AzureRmVMCustomScriptExtension -ResourceGroupName $RGName -VMName ACME-EX01 -Name "CustomScript" -Force
    #region Finish Exchange Server Deployment - run custom script to download files and install prereqs
   
    $CustomScriptExtHt = @{
        Name = "CustomScript"
        ResourceGroupName = $RGName
        VMName = "ACME-EX01"
        FileUri = "{0}Finalize-ACME-EX01.ps1" -f $DSCAssetLocation
        Run = "Finalize-ACME-EX01.ps1"
        Location = $Location
    }
    Set-AzureRmVMCustomScriptExtension @CustomScriptExtHt -Verbose -ErrorAction Stop
    Restart-AzureRmVM -Name ACME-EX01 -ResourceGroupName $RGName -Verbose
    
    Start-JDSleep -sleeptime 160 -message "Waiting for machine to respond"
    Remove-AzureRmVMCustomScriptExtension -ResourceGroupName $RGName -VMName ACME-EX01 -Name "CustomScript" -Force
    Remove-AzureRmVMDscExtension -ResourceGroupName $RGName -VMName ACME-EX01 -Name 'InstallExchange' 
    Remove-AzureRmVMExtension -ResourceGroupName $RGName -VMName ACME-EX01 -Name "joindomain" -Force

    Get-AzureRmVM | ForEach-Object {
        Write-Verbose "Stopping VM $($_.Name) "
        $_ | Stop-AzureRmVM -Force
    }
    stop-transcript

}