﻿$DomainName = "lab22307.o365ready.com"
$RecordsToAdd = @("smtp","anywhere","webmail","autodiscover")

#Get the external IP of the DC and the other machines
$ExternalIP = (Invoke-Command -ComputerName ACME-DC01 -ScriptBlock {(New-Object System.Net.WebClient).Downloadstring("http://myexternalip.com/raw") }).tostring().trim()
Add-DnsServerPrimaryZone -Name $DomainName -ZoneFile "$($DomainName).dns" -Verbose

foreach ($Record in $RecordsToAdd) {
    Add-DnsServerResourceRecordA -ZoneName $DomainName -Name $Record -IPv4Address $ExternalIP -Verbose
}