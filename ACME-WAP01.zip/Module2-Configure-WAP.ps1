﻿$Credentials = Get-Credential -UserName "CORP\sysadmin" -Message "Enter the admin password"
$Certificate = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object {$_.Subject -match "o365ready"}
$FederationServiceName = ($Certificate.DnsNameList | Where-Object {$_ -match "sts"}).UniCode
Add-Content -Value "10.0.10.100     $FederationServiceName" `
            -Path c:\windows\system32\drivers\etc\hosts -Force 

Install-WebApplicationProxy -CertificateThumbprint $Certificate.Thumbprint `
                            -FederationServiceTrustCredential $Credentials `
                            -FederationServiceName $FederationServiceName -Verbose